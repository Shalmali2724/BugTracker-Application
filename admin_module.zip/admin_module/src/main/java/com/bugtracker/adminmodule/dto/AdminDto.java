package com.bugtracker.adminmodule.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdminDto {
	private String adminName;
	private String adminAddress;
	private String adminContact;
	private String adminEmail;
	private String role;
	private String password;
	
	
	
}
