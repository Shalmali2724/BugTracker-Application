package com.bugtracker.projectmngmodule.service;



import java.util.List;

import com.bugtracker.projectmngmodule.dto.ProjectDto;
import com.bugtracker.projectmngmodule.entity.Project;


public interface ProjectService {
	public ProjectDto addProject(ProjectDto projectDto);
	public String deleteProjectById(long projectId);
	public Project updateProject(Project project);
	public Project getProjectById(long projectId);
	public List<Project> getAllProject();
	
	
}
