package com.bugtracker.projectmngmodule.exception;

public class AdminNotFound extends RuntimeException {
	public AdminNotFound(String msg)
	{
		super(msg);
	}

}
