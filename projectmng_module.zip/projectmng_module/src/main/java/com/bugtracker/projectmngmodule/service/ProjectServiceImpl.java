package com.bugtracker.projectmngmodule.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.bugtracker.projectmngmodule.dto.ProjectDto;
import com.bugtracker.projectmngmodule.entity.Admin;
import com.bugtracker.projectmngmodule.entity.Project;
import com.bugtracker.projectmngmodule.exception.AdminNotFound;
import com.bugtracker.projectmngmodule.exception.ProjectNotFoundException;
import com.bugtracker.projectmngmodule.repository.AdminRepository;
import com.bugtracker.projectmngmodule.repository.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository projectRepository;
	@Autowired
	private AdminRepository adminRepository;

	@Override
	public ProjectDto addProject(ProjectDto projectDto) {

		Project projectObj = new Project();
		projectObj.setProjId(projectDto.getProjectId());
		projectObj.setProjName(projectDto.getProjectName());
		projectObj.setProjStatus(projectDto.getProjectStatus());

		Optional<Admin> optionalAdmin = adminRepository.findById(projectDto.getAdminId());
		if (optionalAdmin.isEmpty()) {

			throw new AdminNotFound(" admin is not exists");

		}

		Admin admin = optionalAdmin.get();

		Project newProject = projectRepository.save(projectObj);
		// Create and return a ProjectDto object based on the saved project
		ProjectDto newProjectDto = new ProjectDto();
		newProjectDto.setProjectId(newProject.getProjId());
		newProjectDto.setProjectName(newProject.getProjName());
		newProjectDto.setProjectStatus(newProject.getProjStatus());

		return newProjectDto;

	}

	@Override
	public String deleteProjectById(long projectId) {
		Optional<Project> optional = projectRepository.findById(projectId);

		if (optional.isEmpty()) {
			throw new ProjectNotFoundException("Id Not Exists :" + projectId);
		}
		Project project = optional.get();
		projectRepository.delete(project);
		return "Project deleted";
	}

	@Override
	public Project updateProject(Project project) throws ProjectNotFoundException {
		Optional<Project> optionalProject = projectRepository.findById(project.getProjId());
		if (optionalProject.isEmpty()) {
			throw new ProjectNotFoundException("Project not existing with id:" + project.getProjId());
		}
		Project updatedProject = projectRepository.save(project);
		return updatedProject;
		
		
	}

	@Override
	public Project getProjectById(long projectId) throws ProjectNotFoundException {
		Optional<Project> optionalProject = projectRepository.findById(projectId);
		if (optionalProject.isEmpty()) {
			throw new ProjectNotFoundException("Project not existing with id:" + projectId);
		}
		Project project = optionalProject.get();

		return project;
		
	}

	@Override
	public List<Project> getAllProject() {
		List<Project> project = projectRepository.findAll();
		
		return project;
	}

}
