package com.bugtracker.projectmngmodule.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.bugtracker.projectmngmodule.entity.Project;
import com.bugtracker.projectmngmodule.repository.AdminRepository;
import com.bugtracker.projectmngmodule.repository.ProjectRepository;

@SpringBootTest
public class ProjectServiceTest {
	
	
	@InjectMocks
	private ProjectServiceImpl ProjectService;
	
	@Mock
	private ProjectRepository projectRepository;
	
	@InjectMocks
	private AdminServiceImpl adminService = new AdminServiceImpl();

	@Mock
	private AdminRepository adminRepository;
	
	@Test
	void testGetAllProject() {
		List<Project> projects = new ArrayList<>();
		
	}
	
	
	
	

}
