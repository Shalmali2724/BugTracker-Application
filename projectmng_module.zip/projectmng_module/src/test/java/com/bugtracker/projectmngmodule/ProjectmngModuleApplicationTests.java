package com.bugtracker.projectmngmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectmngModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
